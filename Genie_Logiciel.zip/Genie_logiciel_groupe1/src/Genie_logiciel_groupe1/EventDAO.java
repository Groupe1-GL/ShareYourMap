package Genie_logiciel_groupe1;

public interface EventDAO {
	public char getStarting_date();
	public char getEnding_date();
	public char getTime();
}
