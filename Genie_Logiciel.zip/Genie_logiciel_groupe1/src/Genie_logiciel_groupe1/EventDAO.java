package Genie_logiciel_groupe1;

import java.util.Date;

public interface EventDAO {
	public Date getStarting_date();
	public Date getEnding_date();
	public Date getTime();
}
