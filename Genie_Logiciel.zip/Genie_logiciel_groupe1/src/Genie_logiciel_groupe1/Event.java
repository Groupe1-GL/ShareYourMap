package Genie_logiciel_groupe1;

public class Event extends Location{
	private char[] starting_date;
	private char[] ending_date;
	private char[] time;
	
	
}
