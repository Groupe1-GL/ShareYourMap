package Genie_logiciel_groupe1;

public interface UserDAO {
	public String getMap();  //return map's name
	public void putMap(Map m);  //Add a favorite to the map�s list
	public void deleteMap(Map m);  //Delete a favorite to the map�s list
	public Position getCurrent_Position();  // return current position
}
