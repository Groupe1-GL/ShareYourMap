package Genie_logiciel_groupe1;

import java.util.ArrayList;
import java.util.*;

public class Location{
	private int Loc_ID;
	private String name, creator_name, description, message;
	private Position pos;
	private boolean label;
	//private List<image> image;
	
	
}
