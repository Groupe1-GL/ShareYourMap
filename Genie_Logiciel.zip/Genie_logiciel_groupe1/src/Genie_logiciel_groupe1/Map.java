package Genie_logiciel_groupe1;

import java.util.ArrayList;
import java.util.List;

public class Map implements MapDAO{
	private int Map_ID;
	private String name, creatorName;
	private boolean access_type;
	private List<Location> favourite_locations;
}
