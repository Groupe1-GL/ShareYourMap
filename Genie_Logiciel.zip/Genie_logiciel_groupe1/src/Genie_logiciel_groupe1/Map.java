package Genie_logiciel_groupe1;

import java.util.ArrayList;

public class Map {
	private int Map_ID;
	private String name, creatorName;
	private boolean access_type;
	private ArrayList favourite_locations = new ArrayList();
}
