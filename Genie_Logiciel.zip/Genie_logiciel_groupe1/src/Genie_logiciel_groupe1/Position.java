package Genie_logiciel_groupe1;


public class Position {
	private float x;
	private float y;
}
