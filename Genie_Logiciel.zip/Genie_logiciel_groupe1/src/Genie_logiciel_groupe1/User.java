package Genie_logiciel_groupe1;

import java.util.ArrayList;
import java.util.*;

public class User implements UserDAO{
	private int User_ID;
	private String name;
	private List<Map> listMap; 
	private List<User> listUser;
	private Position current_position;
	
	
	
	@Override
	public String getUser() {  //return the name
		// TODO Auto-generated method stub
		return this.name;
	}
	@Override
	public void putUser(User name) {  //add an user in the list of user
		// TODO Auto-generated method stub
		listUser.add(name);
	}
	@Override
	public void deleteUser(User name) {  //delete an user from the list of user
		// TODO Auto-generated method stub
		listUser.remove(name);
	}
	@Override
	public void putMap(Map m) {
		// TODO Auto-generated method stub
		listMap.add(m);
	}
	@Override
	public void deleteMap(Map m) {
		// TODO Auto-generated method stub
		listMap.remove(m);
	}
	@Override
	public Position getCurrent_Position() {
		// TODO Auto-generated method stub
		return current_position;
	}
	
	
	
}
