package Genie_logiciel_groupe1;

import java.util.ArrayList;
import java.util.*;

public class User implements UserDAO{
	private int User_ID;
	private String name;
	private List<Map> listMap; 
	private Position current_position;
	
	
	
	@Override
	public void putMap(Map m) {
		// TODO Auto-generated method stub
		listMap.add(m);
	}
	@Override
	public void deleteMap(Map m) {
		// TODO Auto-generated method stub
		listMap.remove(m);
	}
	@Override
	public Position getCurrent_Position() {
		// TODO Auto-generated method stub
		return this.current_position;
	}
	@Override
	public String getMap() {
		// TODO Auto-generated method stub
		return this.name;
	}
	
	
}
