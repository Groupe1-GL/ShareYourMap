package Genie_logiciel_groupe1;

public interface MapDAO {
	//je sais pas quoi mettre ici
}
