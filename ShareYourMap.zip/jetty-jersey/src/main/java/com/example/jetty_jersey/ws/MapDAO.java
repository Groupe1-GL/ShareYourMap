package com.example.jetty_jersey.ws;

import java.util.List;

public interface MapDAO {
	//je sais pas quoi mettre ici
	
	//getLocations...
	public List<Location> getLocations();
	public boolean addLocation(Location l);
	
}
