package com.example.jetty_jersey.ws;



public class Position {
	private float x;
	private float y;
}
