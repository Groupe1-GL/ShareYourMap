function getServerDataTxt(url, success){
    $.ajax({
    	type: 'GET',
        dataType: "text",
        url: url
    }).done(success);
}

function getServerDataLambda(url, success){
    $.ajax({
    	type: 'GET',
        url: url
    }).done(success);
}

function getServerData(url, success){
    $.ajax({
    	type:'GET',
        dataType: "json",
        url: url
    }).done(success);
}

function putServerData(url, success){
    $.ajax({
    	type: 'PUT',
        dataType: "json",
        url: url
    }).done(success);
}

function postServerData(url, success){
    $.ajax({
    	type: 'POST',
        dataType: "json",
        url: url
    }).done(success);
}

function deleteServerData(url, success){
    $.ajax({
    	type: 'DELETE',
        dataType: "json",
        url: url
    }).done(success);
}


$(function(){
	getServerDataLambda("/ws/viewmap/1",callDone);
});


function callDone(result){
	var templateExample = _.template($('#templateExample').html());

	var html = templateExample({
		"attribute":JSON.stringify(result)
	});

	$("#userName").append(html);
}



$(function(){
	$("#createMap").click(function(){
		postServerData("/ws/viewmap/1/1",callDone2);
	});
});

function callDone2(result){
	var templateExample = _.template($('#templateExample').html());

	var html = templateExample({
		"attribute":JSON.stringify(result)
	});

	$("#resAddMap").append(html);
}



$(function(){
	$("#addLocation").click(function(){
		getServerData("/viewmap/viewlocation/1/1",callDone3);
	});
});

function callDone3(result){
	var templateExample = _.template($('#templateExample').html());

	var html = templateExample({
		"attribute":JSON.stringify(result)
	});

	$("#resAddLocation").append(html);
}
